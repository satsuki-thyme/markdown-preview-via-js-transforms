'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {stripTypeScriptTypes}=require('node:module');
const base=path.resolve(__dirname,'../evidence/official');
const read=p=>fs.readFileSync(path.join(base,p),'utf8');
const localize=(_id,s,...args)=>s.replace(/\{(\d+)\}/g,(_,i)=>String(args[Number(i)]));
function evaluate(source,values={}){const box=vm.createContext({localize,...values});vm.runInContext(stripTypeScriptTypes(source,{mode:'transform'}),box);return box;}
function nls(){
 const source=read('extensionNls.ts').replace(/^import .*;\r?$/gm,'').replace(/\bexport /g,'');
 return evaluate(source+'\nglobalThis.api=localizeManifest;', {isString:x=>typeof x==='string',isObject:x=>x!==null&&typeof x==='object'&&!Array.isArray(x)}).api;
}
test('N1-S1: execute actual VS Code 1.105.1 manifest localizer, preserves English alias',()=>{
 const input={name:'n1',contributes:{commands:[{command:'stable.id',title:'%name%'}]}};
 const output=nls()({warn(){},error(e){throw Error(e);}},input,{name:'日本語表示'},{name:'English title'});
 assert.equal(output.contributes.commands[0].title.value,'日本語表示');assert.equal(output.contributes.commands[0].title.original,'English title');assert.equal(output.contributes.commands[0].command,'stable.id');
});
test('N1-S2: missing NLS translation falls back; extension auto/en/ja config does not enter localizer',()=>{
 const localizer=nls();
 for(const setting of ['auto','en','ja']){
  const input={name:'n1',contributes:{commands:[{command:'stable.id',title:'%name%'}]},configuration:{language:setting}};
  localizer({warn(){},error(e){throw Error(e);}},input,{}, {name:'English title'});
  assert.equal(input.contributes.commands[0].title,'English title');
 }
});
function picker(){
 const source=read('commandsQuickAccess-base.ts');
 const start=source.indexOf('\tprivate toCommandPick(');const end=source.indexOf('\n\tprivate getTfIdfChunk',start);
 assert(start>0&&end>start);
 const method=source.slice(start,end);
 return evaluate('class Fixture {\n'+method+'\n}\nglobalThis.Fixture=Fixture;').Fixture;
}
test('N1-S3: actual 1.105.1 picker resolves keys by alias ID, not forwarded original ID',()=>{
 const F=picker();const f=new F();const key={getAriaLabel:()=> 'Ctrl+Alt+R'};
 f.options={showAlias:true};f.keybindingService={lookupKeybinding:id=>id==='stable.id'?key:undefined};
 assert.strictEqual(f.toCommandPick({commandId:'stable.id',label:'Title'}).keybinding,key);
 assert.equal(f.toCommandPick({commandId:'stable.id.n1_ja',label:'日本語'}).keybinding,undefined);
});
test('N1-S4: actual 1.105.1 picker alias detail depends on host showAlias and history uses displayed ID',async()=>{
 const F=picker();const f=new F(),history=[],runs=[];
 Object.assign(f,{options:{showAlias:true},keybindingService:{lookupKeybinding:()=>undefined},commandsHistory:{push:id=>history.push(id)},telemetryService:{publicLog2(){}},commandService:{executeCommand:async id=>runs.push(id)}});
 const pick={commandId:'stable.id.n1_ja',label:'日本語',commandAlias:'English title'};
 const result=f.toCommandPick(pick);assert.equal(result.detail,'English title');await result.accept();
 assert.deepEqual(history,['stable.id.n1_ja']);assert.deepEqual(runs,['stable.id.n1_ja']);
 f.options.showAlias=false;assert.equal(f.toCommandPick(pick).detail,undefined);
});
