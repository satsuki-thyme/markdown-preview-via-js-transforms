'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createNavigation}=require('../probe-extension/navigation.cjs');
const {MARKDOWN_PREVIEW_EDITOR}=require('../src/open-preview.cjs');
class Uri { constructor(p,scheme='file'){this.path=p;this.fsPath=p;this.scheme=scheme;} toString(){return this.scheme+':'+this.path;} static file(p){return new Uri(p);} }
class TabInputCustom {constructor(uri,viewType=MARKDOWN_PREVIEW_EDITOR){this.uri=uri;this.viewType=viewType;}}
class TabInputText {constructor(uri){this.uri=uri;}}
function setup(){
 const calls=[];const input=Uri.file('/n1/a.md');
 const group={viewColumn:1,tabs:[{input:new TabInputText(input)}]};
 const document={uri:input,isDirty:true,getText:()=> 'unsaved 日本語 🌿',save:()=>{throw Error('must not save');}};
 const editor={document,selections:[{anchor:2,active:4}],visibleRanges:[{start:1,end:9}],revealRange:r=>calls.push(['revealRange',r])};
 const v={Uri,TabInputCustom,TabInputText,TextEditorRevealType:{AtTop:1},
  window:{activeTextEditor:editor,tabGroups:{all:[group],activeTabGroup:group,close:()=>{throw Error('must not close');}},showTextDocument:async(doc,opts)=>{calls.push(['showTextDocument',doc,opts]);return editor;}},
  workspace:{getWorkspaceFolder:()=>({uri:Uri.file('/n1')}),fs:{stat:async()=>({})},openTextDocument:async uri=>{calls.push(['openTextDocument',uri]);return uri.scheme==='file'?document:{uri};}},
  commands:{executeCommand:async(...a)=>{calls.push(['executeCommand',...a]);}}};
 const preview={uriFor:p=>new Uri(p+'.js-transforms-preview.md','markdown-preview-via-js-transforms')};
 const a={pair:{input:'/n1/a.md',root:'/n1',script:'/n1/transforms/identity.cjs'},markdown:'A',time:1};
 const b={pair:{input:'/n1/b.md',root:'/n1',script:'/n1/transforms/identity.cjs'},markdown:'B',time:2};
 const nav=createNavigation(v,preview,a);
 return {v,nav,preview,a,b,calls,input,group,document,editor};
}
test('N1-A1: request current group without saving, closing or claiming one tab',async()=>{
 const s=setup();const r=await s.nav.showSameRegion();
 assert.equal(r.status,'open-requested');assert.equal(r.column,1);assert.equal(r.strictSameTab,false);assert.equal(r.guiVerified,false);
 const c=s.calls.find(x=>x[0]==='executeCommand');assert.equal(c[1],'vscode.openWith');assert.equal(c[3],MARKDOWN_PREVIEW_EDITOR);assert.deepEqual(c[4],{viewColumn:1,preview:false});
 assert.equal(s.document.getText(),'unsaved 日本語 🌿');assert.equal(s.document.isDirty,true);
});
test('N1-A2: same-group result requests the same URI; other URI/view type is ignored',async()=>{
 const s=setup();s.group.tabs.push({input:new TabInputCustom(s.preview.uriFor(s.a.pair.input))},{input:new TabInputCustom(s.preview.uriFor('/n1/b.md'))},{input:new TabInputCustom(s.preview.uriFor(s.a.pair.input),'other.editor')});
 assert.equal(s.nav.matches(s.preview.uriFor(s.a.pair.input)).length,1);
 assert.equal((await s.nav.showSameRegion()).status,'open-requested');
});
test('N1-A3: cross-group or duplicate results are blocked; no silent other-group success',async()=>{
 const s=setup();s.v.window.tabGroups.all.push({viewColumn:2,tabs:[{input:new TabInputCustom(s.preview.uriFor(s.a.pair.input))}]});
 assert.equal((await s.nav.showSameRegion()).status,'cross-group-unverified');assert.equal(s.calls.length,0);
 assert.equal((await s.nav.showSameRegion(true)).status,'open-requested');
 // Raw command requests another group only; this test does not simulate VS Code tab reuse.
});
test('N1-A4: return from A uses A after B succeeds, retains original document object',async()=>{
 const s=setup();await s.nav.showSameRegion();s.nav.remember(s.b);
 s.group.activeTab={input:new TabInputCustom(s.preview.uriFor(s.a.pair.input))};s.v.window.activeTextEditor=undefined;
 const r=await s.nav.back();assert.equal(r.input,'file:/n1/a.md');assert.equal(r.selectionRequested,true);
 assert.strictEqual(s.calls.find(x=>x[0]==='showTextDocument')[1],s.document);
 assert.deepEqual(s.editor.selections,[{anchor:2,active:4}]);assert(s.calls.some(x=>x[0]==='revealRange'));
});
test('N1-A5: return finds a manually moved source tab by URI',async()=>{
 const s=setup();await s.nav.showSameRegion();const tab=s.group.tabs.pop();s.v.window.tabGroups.all.push({viewColumn:3,tabs:[tab]});
 s.group.activeTab={input:new TabInputCustom(s.preview.uriFor(s.a.pair.input))};
 assert.equal((await s.nav.back()).column,3);
});
test('N1-A6: missing source/root or unknown result never closes preview',async()=>{
 const s=setup();s.group.activeTab={input:new TabInputCustom(s.preview.uriFor(s.a.pair.input))};
 s.v.workspace.fs.stat=async()=>{throw Error('missing');};assert.equal((await s.nav.back()).status,'missing-input');
 s.v.workspace.getWorkspaceFolder=()=>undefined;assert.equal((await s.nav.back()).status,'missing-root');
 s.group.activeTab={input:new TabInputCustom(s.preview.uriFor('/n1/unknown.md'))};assert.equal((await s.nav.back()).status,'unknown-result');assert.equal(s.calls.length,0);
});
test('N1-A7: restored last result can return without transform or remembered selection',async()=>{
 const s=setup();s.group.activeTab={input:new TabInputCustom(s.preview.uriFor(s.a.pair.input))};
 const r=await s.nav.back();assert.equal(r.status,'return-requested');assert.equal(r.selectionRequested,false);assert(!s.calls.some(x=>x[0]==='executeCommand'));
});
test('N1-A8: absent snapshot and non-input stop without executing a transform',async()=>{
 const s=setup();s.editor.document.uri=Uri.file('/n1/never.md');assert.equal((await s.nav.showSameRegion()).status,'no-snapshot');
 s.v.window.activeTextEditor=undefined;assert.equal((await s.nav.showSameRegion()).status,'not-input');assert.equal(s.calls.length,0);
});
