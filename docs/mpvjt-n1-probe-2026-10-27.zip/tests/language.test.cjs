'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {registerAliases,message,resolveLanguage,NAMESPACE}=require('../probe-extension/language.cjs');
const manifest=require('../probe-extension/package.json');
const baseline=require('../package.json');
function visible(setting){
 return manifest.contributes.menus.commandPalette.filter(item=>item.when.split(' && ').every(term=>{
  const m=term.match(/^config\.markdownPreviewViaJsTransforms\.language (!=|==) (en|ja)$/);assert(m);
  return m[1]==='=='?setting===m[2]:setting!==m[2];
 })).map(x=>x.command);
}
test('N1-L1: host en/ja crossed with auto/en/ja plus non-Japanese fallback',()=>{
 for(const host of ['en','ja'])for(const setting of ['auto','en','ja'])assert.equal(resolveLanguage(setting,host),setting==='auto'?host:setting);
 assert.equal(resolveLanguage('auto','fr'),'en');assert.equal(resolveLanguage('auto','ja-JP'),'ja');assert.equal(resolveLanguage(undefined,'ja'),'ja');
});
test('N1-L2: manifest predicates select one entrance per operation before extension activation',()=>{
 for(const setting of [undefined,'auto','en','ja','invalid']){
  const ids=visible(setting);assert.equal(ids.length,5);assert.equal(new Set(ids).size,5);
  for(const cmd of baseline.contributes.commands) assert.equal(ids.filter(id=>id===cmd.command||id.startsWith(cmd.command+'.')).length,1);
 }
 assert(visible('en').every(id=>id.endsWith('.n1_en')));assert(visible('ja').every(id=>id.endsWith('.n1_ja')));
 // Predicate evaluation only. Workbench palette rendering/MRU refresh is untested.
});
test('N1-L3: all ten aliases dispatch unchanged canonical IDs and argument values',async()=>{
 const handlers=new Map(),calls=[];
 const v={commands:{registerCommand:(id,fn)=>{handlers.set(id,fn);return {dispose(){}};},executeCommand:async(...args)=>{calls.push(args);return 'result';}}};
 registerAliases(v,{subscriptions:[]});assert.equal(handlers.size,10);
 for(const [id,fn] of handlers){const arg={input:'日本語'};assert.equal(await fn(arg),'result');const call=calls.at(-1);assert.equal(call[0],id.replace(/\.n1_(en|ja)$/,''));assert.strictEqual(call[1],arg);}
 assert.equal(manifest.contributes.keybindings,undefined);
 assert.deepEqual(manifest.contributes.commands.filter(x=>baseline.contributes.commands.some(y=>x.command===y.command)).map(x=>x.command),baseline.contributes.commands.map(x=>x.command));
});
test('N1-L4: messages change language while original error/path and source bytes remain untouched',()=>{
 const raw='原例外 C:\\N1\\input.md 🌿';assert(message('en','ja','error',raw).startsWith('Sample failure.'));assert(message('ja','en','error',raw).startsWith('試験用'));
 for(const lang of ['en','ja'])assert(message(lang,'en','error',raw).endsWith(raw));
 const core=path.resolve(__dirname,'../src');
 for(const name of fs.readdirSync(core))assert(fs.readFileSync(path.join(core,name)).equals(fs.readFileSync(path.resolve(__dirname,'../probe-extension/src',name))),name);
});
