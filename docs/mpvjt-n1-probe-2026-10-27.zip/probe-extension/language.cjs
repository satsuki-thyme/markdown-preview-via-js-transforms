'use strict';
const NAMESPACE = 'markdownPreviewViaJsTransforms';
function resolveLanguage(setting, host) {
  if (setting === 'en' || setting === 'ja') return setting;
  return /^ja(?:-|$)/i.test(host || '') ? 'ja' : 'en';
}
const messages = {
  en: { info: 'Cached result retained; no transform was run.', error: 'Sample failure. Original details: {0}' },
  ja: { info: '保持済みの結果を維持しました。変換は実行していません。', error: '試験用の失敗です。原文の詳細: {0}' }
};
function message(setting, host, name, raw = '') {
  return messages[resolveLanguage(setting,host)][name].replace('{0}',raw);
}
function registerAliases(v, context) {
  for (const name of ['selectAndRun','rerun','reopenPreview','cancel','showLog']) {
    for (const lang of ['en','ja']) {
      const canonical = `${NAMESPACE}.${name}`;
      context.subscriptions.push(v.commands.registerCommand(`${canonical}.n1_${lang}`, (...args) => v.commands.executeCommand(canonical, ...args)));
    }
  }
}
module.exports = { NAMESPACE, resolveLanguage, message, registerAliases };
