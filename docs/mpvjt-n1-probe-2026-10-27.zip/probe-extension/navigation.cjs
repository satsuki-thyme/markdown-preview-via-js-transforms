'use strict';
const path = require('node:path');
const { MARKDOWN_PREVIEW_EDITOR } = require('./src/open-preview.cjs');
const { inputExtensions } = require('./src/paths.cjs');

// N1 experiment only. No source-tab close, replacement, save, edit or transform.
function createNavigation(v, preview, initialRecord) {
  const records = new Map();
  const positions = new Map();
  const key = u => u.toString();
  function remember(record) {
    if (record) records.set(key(preview.uriFor(record.pair.input)), record.pair);
  }
  remember(initialRecord);
  function matches(uri) {
    return v.window.tabGroups.all.flatMap(group => group.tabs
      .filter(tab => tab.input instanceof v.TabInputCustom && tab.input.viewType === MARKDOWN_PREVIEW_EDITOR && key(tab.input.uri) === key(uri))
      .map(tab => ({ group, tab })));
  }
  function currentPreview() {
    const tab = v.window.tabGroups.activeTabGroup.activeTab;
    return tab?.input instanceof v.TabInputCustom && tab.input.viewType === MARKDOWN_PREVIEW_EDITOR ? tab.input.uri : undefined;
  }
  async function showSameRegion(raw = false) {
    const editor = v.window.activeTextEditor;
    if (!editor || editor.document.uri.scheme !== 'file' || !inputExtensions.has(path.extname(editor.document.uri.fsPath).toLowerCase())) return { status: 'not-input' };
    const input = editor.document.uri;
    const uri = preview.uriFor(input.fsPath);
    if (!records.has(key(uri))) return { status: 'no-snapshot' };
    const column = v.window.tabGroups.activeTabGroup.viewColumn;
    const found = matches(uri);
    if (!raw && (found.length > 1 || found.some(x => x.group.viewColumn !== column))) return { status: 'cross-group-unverified', groups: found.map(x => x.group.viewColumn) };
    positions.set(key(uri), { column, selections: [...editor.selections], range: editor.visibleRanges?.[0] });
    await v.workspace.openTextDocument(uri);
    await v.commands.executeCommand('vscode.openWith', uri, MARKDOWN_PREVIEW_EDITOR, { viewColumn: column, preview: false });
    return { status: 'open-requested', input: key(input), result: key(uri), column, strictSameTab: false, guiVerified: false };
  }
  async function back() {
    const uri = currentPreview();
    const pair = uri && records.get(key(uri));
    if (!pair) return { status: 'unknown-result' };
    const input = v.Uri.file(pair.input);
    const folder = v.workspace.getWorkspaceFolder(input);
    if (!folder || path.resolve(folder.uri.fsPath) !== path.resolve(pair.root)) return { status: 'missing-root' };
    try { await v.workspace.fs.stat(input); } catch { return { status: 'missing-input' }; }
    const found = v.window.tabGroups.all.find(group => group.tabs.some(tab => tab.input instanceof v.TabInputText && key(tab.input.uri) === key(input)));
    const remembered = positions.get(key(uri));
    const stillExists = remembered && v.window.tabGroups.all.some(g => g.viewColumn === remembered.column);
    const column = found?.viewColumn ?? (stillExists ? remembered.column : v.window.tabGroups.activeTabGroup.viewColumn);
    const document = await v.workspace.openTextDocument(input);
    const editor = await v.window.showTextDocument(document, { viewColumn: column, preview: false });
    if (remembered) {
      editor.selections = remembered.selections;
      if (remembered.range) editor.revealRange(remembered.range, v.TextEditorRevealType.AtTop);
    }
    return { status: 'return-requested', input: key(input), column, selectionRequested: !!remembered, guiVerified: false };
  }
  return { remember, showSameRegion, back, matches, currentPreview };
}
module.exports = { createNavigation };
