'use strict';
const v = require('vscode');
const base = require('./src/extension.cjs');
const { createNavigation } = require('./navigation.cjs');
const { NAMESPACE, message, registerAliases } = require('./language.cjs');
exports.activate = async context => {
  if (context.extensionMode === v.ExtensionMode.Production) throw new Error('N1 probe must run with --extensionDevelopmentPath in an isolated profile.');
  const api = base.activate(context);
  const out = v.window.createOutputChannel('MPVJT N1 Observations');
  context.subscriptions.push(out);
  const nav = createNavigation(v, api.preview, api.controller.state().last);
  let successEvents = 0;
  // Instrumentation only: preserve the original put behavior and capture its mapping.
  const put = api.preview.put;
  api.preview.put = record => { const result=put(record); nav.remember(record);successEvents++;return result; };
  const log = value => { out.appendLine(JSON.stringify({at:new Date().toISOString(),...value},null,2)); out.show(true); };
  const observe = () => log({
    vscode:v.version,node:process.versions.node,hostLanguage:v.env.language,
    setting:v.workspace.getConfiguration(NAMESPACE).get('language','auto'),
    successEventsSinceActivation:successEvents,
    lastPair:api.controller.state().last?.pair,
    groups:v.window.tabGroups.all.map(g=>({column:g.viewColumn,active:g.isActive,tabs:g.tabs.map(t=>({label:t.label,type:t.input?.constructor?.name,uri:t.input?.uri?.toString(),viewType:t.input?.viewType,dirty:t.isDirty,preview:t.isPreview,active:t.isActive}))}))
  });
  const actions = {
    sameRegion: async () => log(await nav.showSameRegion()),
    rawOpen: async () => log(await nav.showSameRegion(true)),
    back: async () => log(await nav.back()),
    observe,
    sampleInfo: () => v.window.showInformationMessage(message(v.workspace.getConfiguration(NAMESPACE).get('language','auto'),v.env.language,'info')),
    sampleError: () => v.window.showErrorMessage(message(v.workspace.getConfiguration(NAMESPACE).get('language','auto'),v.env.language,'error','N1 原例外 RAW_ERROR C:\\N1\\input.md'))
  };
  for (const lang of ['auto','en','ja']) actions['language'+lang[0].toUpperCase()+lang.slice(1)] = () => v.workspace.getConfiguration(NAMESPACE).update('language',lang,v.ConfigurationTarget.Global);
  for(const [name,fn] of Object.entries(actions)) context.subscriptions.push(v.commands.registerCommand('mpvjtN1.'+name,fn));
  registerAliases(v,context);
  observe();
  return { ...api, nav, observe };
};
