from pathlib import Path
import subprocess, datetime, json, sys, platform
root=Path(__file__).resolve().parent
logs=root/'logs';logs.mkdir(exist_ok=True)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
files=sorted((root/'baseline-tests').glob('*.test.cjs'))+sorted((root/'tests').glob('*.test.cjs'))
run=subprocess.run(['node','--test',*[str(p) for p in files]],cwd=root,capture_output=True,text=True)
p=logs/f'node-tests-{stamp}.log'
with p.open('x',encoding='utf-8') as f:f.write(run.stdout+'\nSTDERR\n'+run.stderr+f'\nEXIT_CODE={run.returncode}\n')
summary={'log':p.name,'exit_code':run.returncode,'node':subprocess.check_output(['node','--version'],text=True).strip(),'platform':platform.platform(),'gui_executed':False,'evidence':'real Worker + fake VS Code API + isolated official pure-function execution'}
with (logs/f'summary-{stamp}.json').open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2)
print(run.stdout[-4500:]);print(run.stderr[-1500:]);print(json.dumps(summary))
sys.exit(run.returncode)
