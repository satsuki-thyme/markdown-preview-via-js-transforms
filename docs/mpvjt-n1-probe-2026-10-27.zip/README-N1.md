# MPVJT N1検証キット

2026-10-27。製品版・VSIXではない。N1の隔離試験用ソースと証拠。

- 結論・方式比較: `mpvjt-n1-validation-2026-10-27.md`
- 実機手順: `GUI-CHECKLIST.md`（すべて未実施）
- Windows専用起動: `Launch-N1.ps1`（静的確認のみ）
- 非GUI再試験: Node.js 24.22.1＋Python 3で `python run-tests.py`
- 最終試験ログ: `logs/node-tests-20261027T043853Z.log`（40合格、終了コード0）
- 前の試験ログ: `logs/node-tests-20261027T043726Z.log`（試験ハーネスのTypeScript処理で2失敗。修正前も保持）

`probe-extension/src`はDropboxから生取得した製品8ファイルと同一。追加した`n1-extension.cjs`、`navigation.cjs`、`language.cjs`と試験用manifestがN1専用部分。

ルートのpackage.jsonとsrc、baseline-testsは既存試験の再現用。ここで`npm run package`や`npm run test:integration`を使わない。実機確認は上記専用ランチャーだけを使い、本番ワークスペース・通常プロファイルへ適用しない。VSIXを生成・インストールする工程はない。

新規の試験変換サンプルはidentity（入力をそのまま返す）と異常系だけ。用途別変換は実装していない。独自言語の案内試験は代表メッセージに限定し、製品全体を翻訳したものではない。

実機結果は新しい文書へ記録する。本キットや既存受入記録をそのまま上書きしない。試験後のファイル・セッションは自動削除しない。

Concept, Direction & Product Ownership: SATSUKI Thyme  
AI-assisted Engineering: ChatGPT
