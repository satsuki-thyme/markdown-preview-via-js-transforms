# N1 専用入力 A 🌿

![N1 square](assets/square.svg)

[Read-only relative link](linked.txt)

手動実行の結果だけを表示する。
