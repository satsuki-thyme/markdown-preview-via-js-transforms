module.exports = () => new Promise(() => {});
