module.exports = () => 42;
