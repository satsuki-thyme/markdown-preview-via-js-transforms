module.exports = async function ({ text, filePath }) { return text; };
