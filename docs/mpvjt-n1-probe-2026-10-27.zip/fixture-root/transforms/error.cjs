module.exports = () => { throw new Error("N1 原例外 RAW_ERROR"); };
