module.exports = () => { while (true) {} };
