param(
  [Parameter(Mandatory=$true)][string]$CodeExecutable,
  [ValidateSet('en','ja')][string]$Locale = 'en',
  [string]$SessionPath,
  [string]$JapaneseLanguagePackPath
)
$ErrorActionPreference = 'Stop'
$n1Kit = $PSScriptRoot
if (-not (Test-Path -LiteralPath $CodeExecutable -PathType Leaf)) { throw 'Code.exe was not found.' }
if ([string]::IsNullOrWhiteSpace($SessionPath)) {
  $n1Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $n1Session = Join-Path $env:TEMP ('MPVJT-N1-' + $n1Stamp + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
  if (Test-Path -LiteralPath $n1Session) { throw 'Session already exists.' }
  New-Item -ItemType Directory -Path $n1Session | Out-Null
  [IO.File]::WriteAllText((Join-Path $n1Session 'N1-SESSION.txt'), 'MPVJT N1 isolated session', [Text.UTF8Encoding]::new($false))
  Copy-Item -LiteralPath (Join-Path $n1Kit 'fixture-root') -Destination (Join-Path $n1Session 'workspace') -Recurse
  $n1User = Join-Path $n1Session 'user-data\User'
  New-Item -ItemType Directory -Path $n1User | Out-Null
  New-Item -ItemType Directory -Path (Join-Path $n1Session 'extensions') | Out-Null
  $n1Keys = '[{"key":"ctrl+alt+r","command":"markdownPreviewViaJsTransforms.rerun"}]'
  [IO.File]::WriteAllText((Join-Path $n1User 'keybindings.json'), $n1Keys, [Text.UTF8Encoding]::new($false))
  if (-not [string]::IsNullOrWhiteSpace($JapaneseLanguagePackPath)) {
    $n1Pack = Get-Content -LiteralPath (Join-Path $JapaneseLanguagePackPath 'package.json') -Raw | ConvertFrom-Json
    if (($n1Pack.publisher -ne 'MS-CEINTL') -or ($n1Pack.name -ne 'vscode-language-pack-ja')) { throw 'The provided folder is not the Microsoft Japanese language pack.' }
    Copy-Item -LiteralPath $JapaneseLanguagePackPath -Destination (Join-Path $n1Session 'extensions\japanese-language-pack') -Recurse
  }
} else {
  $n1Session = (Resolve-Path -LiteralPath $SessionPath).Path
  if (-not (Test-Path -LiteralPath (Join-Path $n1Session 'N1-SESSION.txt'))) { throw 'Not an N1 session folder.' }
  if ((Get-Content -LiteralPath (Join-Path $n1Session 'N1-SESSION.txt') -Raw) -ne 'MPVJT N1 isolated session') { throw 'Unexpected session marker.' }
}
$n1Extension = (Resolve-Path -LiteralPath (Join-Path $n1Kit 'probe-extension')).Path
Write-Host ('N1_SESSION=' + $n1Session)
Write-Host 'Close this isolated window before resuming the same session. Do not open the production workspace here.'
& $CodeExecutable '--new-window' '--user-data-dir' (Join-Path $n1Session 'user-data') '--extensions-dir' (Join-Path $n1Session 'extensions') ('--extensionDevelopmentPath=' + $n1Extension) ('--locale=' + $Locale) '--skip-welcome' '--skip-release-notes' (Join-Path $n1Session 'workspace')
